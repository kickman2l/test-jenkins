#!/bin/bash

echo "Hello World. Current branch is $BRANCH_NAME"
